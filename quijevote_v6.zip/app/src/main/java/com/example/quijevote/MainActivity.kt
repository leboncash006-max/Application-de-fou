package com.example.quijevote

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

private const val DS_URL = "https://chat.deepseek.com/"
private const val GAME_URL = "https://appassets.androidplatform.net/assets/index.html"
private val BG_COLOR = 0xFF2D0E63.toInt()
private const val CHROME_UA =
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
    "Chrome/124.0.0.0 Mobile Safari/537.36"

/*
 * Script injecté dans DeepSeek. Si DeepSeek change son interface,
 * ajuste SEL_INPUT / SEL_ANSWER (inspection : chrome://inspect sur ton PC).
 * Laisse le mode "DeepThink" désactivé dans DeepSeek.
 */
private const val DS_SCRIPT = """
(async () => {
  const SEL_INPUT = 'textarea';
  const SEL_ANSWER = '.ds-markdown';
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const wait = async (fn, ms) => {
    const t = Date.now();
    while (Date.now() - t < ms) { const v = fn(); if (v) return v; await sleep(500); }
    return null;
  };
  try {
    AndroidDs.status('Connexion à DeepSeek…');
    const input = await wait(() => document.querySelector(SEL_INPUT), 25000);
    if (!input) {
      AndroidDs.error("Zone de saisie introuvable. Connecte-toi d'abord à DeepSeek avec l'engrenage ⚙ en haut à droite de l'accueil.");
      return;
    }
    const before = document.querySelectorAll(SEL_ANSWER).length;
    input.focus();
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    setter.call(input, __PROMPT__);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(900);

    AndroidDs.status('Envoi du profil…');
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    await sleep(1800);
    if (document.querySelectorAll(SEL_ANSWER).length === before && input.value.length > 20) {
      // Plan B : clic sur le dernier bouton proche de la zone de saisie
      const zone = input.closest('div') ? input.closest('div').parentElement : document;
      const btns = Array.from(zone.querySelectorAll('[role="button"], button'))
        .filter(b => b.getAttribute('aria-disabled') !== 'true' && !b.disabled);
      if (btns.length) btns[btns.length - 1].click();
    }

    AndroidDs.status('DeepSeek réfléchit…');
    // Les retours à la ligne « visuels » casseraient JSON.parse : on les aplatit.
    const norm = t => String(t || '').replace(/[\r\n]+/g, ' ').replace(/ /g, ' ');
    const tryParse = (txt) => {
      const c = norm(txt);
      const i = c.indexOf('{'), j = c.lastIndexOf('}');
      if (i < 0 || j <= i) return null;
      const body = c.slice(i, j + 1);
      try {
        const o = JSON.parse(body);
        if (o && o.candidat && o.argumentation && o.candidat !== 'Prénom Nom') return body;
      } catch (e) {}
      return null;
    };
    const looksDone = (txt) => {
      const c = norm(txt);
      return /"candidat"\s*:\s*"[^"]+"/.test(c) && /"argumentation"\s*:\s*"/.test(c)
        && /\}[^{}"]{0,12}$/.test(c) && !/Prénom Nom/.test(c);
    };
    let lastLenient = '', stable = 0, lastRaw = '';
    const t0 = Date.now();
    while (Date.now() - t0 < 225000) {
      await sleep(2000); // on vérifie toutes les 2 secondes
      const els = Array.from(document.querySelectorAll(SEL_ANSWER)).slice(before);
      const texts = els.map(e => e.innerText || '');
      if (texts.length) lastRaw = texts.join(' ');
      const cands = [texts.join(' ')].concat(texts.slice().reverse());
      let lenient = null;
      for (const c of cands) {
        const ok = tryParse(c);
        if (ok) { AndroidDs.result(ok); return; }
        if (!lenient && looksDone(c)) lenient = norm(c);
      }
      if (lenient) {
        if (lenient === lastLenient) stable++; else { stable = 0; lastLenient = lenient; }
        if (stable >= 1) { AndroidDs.result(lenient); return; }
      }
    }
    if (lastRaw.length > 20) { AndroidDs.result(norm(lastRaw)); return; }
    AndroidDs.error("Pas de réponse exploitable de DeepSeek à temps.");
  } catch (e) {
    AndroidDs.error('Erreur script : ' + e);
  }
})();
"""

class MainActivity : AppCompatActivity() {

    private lateinit var game: WebView
    private lateinit var ds: WebView
    private lateinit var dsBox: LinearLayout
    private var pendingPrompt: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(true) // pratique pour déboguer (chrome://inspect)

        game = WebView(this)
        ds = WebView(this)
        dsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
            visibility = View.INVISIBLE // invisible mais bien actif
            addView(Button(context).apply {
                text = "← Retour au jeu"
                setOnClickListener { hideDeepSeek() }
            })
            addView(ds, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(BG_COLOR)
            addView(game, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(dsBox, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }

        // --- WebView du jeu (servie en https local, nécessaire pour Firebase) ---
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        game.setBackgroundColor(BG_COLOR)
        game.settings.javaScriptEnabled = true
        game.settings.domStorageEnabled = true
        game.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                loader.shouldInterceptRequest(request.url)
        }
        game.addJavascriptInterface(GameBridge(), "Android")
        game.loadUrl(GAME_URL)

        // --- WebView DeepSeek (cookies conservés : tu te connectes une seule fois) ---
        ds.settings.javaScriptEnabled = true
        ds.settings.domStorageEnabled = true
        ds.settings.userAgentString = CHROME_UA
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(ds, true)
        ds.addJavascriptInterface(DsBridge(), "AndroidDs")
        ds.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                val p = pendingPrompt ?: return
                pendingPrompt = null
                view.evaluateJavascript(DS_SCRIPT.replace("__PROMPT__", JSONObject.quote(p)), null)
            }
        }
        ds.loadUrl(DS_URL)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (dsBox.visibility == View.VISIBLE) {
                    hideDeepSeek()
                } else {
                    // La page du jeu gère sa propre pile de navigation : true = retour géré, false = on quitte.
                    game.evaluateJavascript(
                        "(typeof window.onAndroidBack === 'function') ? window.onAndroidBack() : false"
                    ) { result ->
                        if (result != "true") finish()
                    }
                }
            }
        })
    }

    private fun showDeepSeek() {
        dsBox.animate().cancel()
        dsBox.alpha = 0f
        dsBox.visibility = View.VISIBLE
        dsBox.animate().alpha(1f).setDuration(220).start()
    }

    private fun hideDeepSeek() {
        dsBox.animate().cancel()
        dsBox.animate().alpha(0f).setDuration(180).withEndAction {
            if (dsBox.alpha == 0f) dsBox.visibility = View.INVISIBLE
        }.start()
    }

    private fun toGame(fn: String, text: String) = runOnUiThread {
        game.evaluateJavascript("window.$fn && window.$fn(${JSONObject.quote(text)})", null)
    }

    /** Appelé par le jeu (window.Android.*) */
    inner class GameBridge {
        @JavascriptInterface fun openDeepSeek() = runOnUiThread { showDeepSeek() }
        @JavascriptInterface fun askDeepSeek(prompt: String) = runOnUiThread {
            pendingPrompt = prompt
            ds.loadUrl(DS_URL) // recharge = nouvelle conversation vierge
        }
    }

    /** Appelé par le script injecté dans DeepSeek (window.AndroidDs.*) */
    inner class DsBridge {
        @JavascriptInterface fun status(m: String) = toGame("onDeepSeekStatus", m)
        @JavascriptInterface fun result(t: String) = toGame("onDeepSeekResult", t)
        @JavascriptInterface fun error(m: String) = toGame("onDeepSeekError", m)
    }
}
